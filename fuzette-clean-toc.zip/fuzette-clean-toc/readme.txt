=== Fuzette Clean HTML TOC ===
Contributors: argong
Tags: table of contents, toc, clean html, lightweight, seo
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Zero-bloat Table of Contents generator that inserts pure, editable HTML anchor lists directly at your cursor position without any frontend CSS or JS.

== Description ==

**Fuzette Clean HTML TOC** is an ultra-lightweight WordPress utility designed by **Argong** with **Gemini** for bloggers, writers, and performance purists.

Unlike traditional Table of Contents plugins that parse content on every page load and enqueue heavy frontend stylesheets and scripts, **Fuzette Clean HTML TOC** works exclusively inside the post editor. With a single click, it scans your headings, assigns clean short IDs (`#fgl1`, `#fgl2`, etc.), and inserts a pure HTML `<ul>` list directly at your cursor position.

= Key Features =
* **Zero Frontend Overhead:** Loads 0 bytes of CSS or JavaScript on your public site.
* **100% Editable Output:** The generated TOC is standard HTML text/list block inside your article—edit, reorder, or delete individual links freely.
* **Permanent & Portable:** Even if you deactivate or uninstall the plugin in the future, all generated TOCs remain intact inside your posts.
* **Universal Editor Compatibility:** Works seamlessly with the Block Editor (Gutenberg), Classic Visual Editor (TinyMCE), and Plain Text/HTML Editor (Quicktags).
* **Custom Depth Control:** Choose heading depth on the fly with dedicated buttons for `H2`, `H3`, or `H4`.

---

**نبذة بالعربية:**
إضافة خفيفة جداً صُممت بواسطة **Argong** بالتعاون مع **Gemini** لتوليد جدول محتويات (فهرس مقالات) بصيغة HTML نقي تماماً وقابل للتعديل المباشر كنص عادي داخل المحرر، دون تحميل أي ملفات CSS أو JavaScript في واجهة الزوار.

== Installation ==

1. Upload the `fuzette-clean-toc` folder to the `/wp-content/plugins/` directory, or upload the ZIP package via **Plugins > Add New > Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Open any post or page in the editor, place your cursor where you want the Table of Contents to appear, and click the `H2`, `H3`, or `H4` button.

== Frequently Asked Questions ==

= Does this plugin slow down my website? =
Not at all. It executes zero PHP, CSS, or JavaScript on the frontend.

= What happens if I uninstall the plugin? =
Your Table of Contents and heading anchor IDs remain permanently saved in your post content as clean HTML.

== Changelog ==

= 1.0.0 =
* Initial release designed by Argong with Gemini.
